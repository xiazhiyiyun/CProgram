#include<stdio.h>
#include<stdlib.h>

#define MAXVAL 100

int sp = 0;
double val[MAXVAL];
