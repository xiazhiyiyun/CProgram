#include <stdio.h>

int main() {
    double d = -2;
    int i = (int)d;
    printf("(int) -2 = %d\n",i);
    printf("test\vtest\n");
    printf("test\ttest\n");
    printf("test\v\test\n");
    printf("test\r\test\n");
    printf("test\fest\n");
}
