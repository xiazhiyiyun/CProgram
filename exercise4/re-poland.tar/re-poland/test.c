#include <stdio.h>

int main() {
    printf("test\vtest\n");
    printf("test\ttest\n");
    printf("test\v\test\n");
    printf("test\r\test\n");
    printf("test\fest\n");
}
